<template>
<OperacionesList/>
</template>

<script setup>
import OperacionesList from 'components/OperacionesList.vue'
</script>