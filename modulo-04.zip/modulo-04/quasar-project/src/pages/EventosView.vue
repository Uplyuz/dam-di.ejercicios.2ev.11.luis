<template>
<EventosList></EventosList>
</template>
<script setup>
import EventosList from 'components/EventosList.vue'
</script>