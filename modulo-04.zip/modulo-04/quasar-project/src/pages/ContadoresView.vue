<template>
    <q-page>
      <ContadoresList />
    </q-page>
  </template>
  
  <script setup>
  import ContadoresList from 'components/ContadoresList.vue'; // Importamos el componente
  </script>
  
  <style scoped>
  /* Estilos adicionales para la vista pueden ir aquí */
  </style>
  